# Conveyor grasp: noise, moving-target miss, contact-triggered retreat

Actual MuJoCo 4.0.1 physics rollouts, not animations. No object weld/teleport. Original 3-translation gantry and two opposing sliding fingers, 80 g cube. Belt command is randomized 0.07–0.13 m/s; bounded tangential driving force while cube touches the static belt approximates a conveyor, not a moving mesh. Motor and friction model are simplified. Observations include privileged simulator poses/velocities.

## Reproduce

Use Python 3.12 and install requirements-lock.txt in a virtual environment (PyTorch CPU builds are available at https://download.pytorch.org/whl/cpu). ffmpeg is required. Run:

```
MUJOCO_GL=egl python experiments.py
```

The bundled policy is the unchanged BC-initialized, PPO-refined policy from the first prototype. No recovery policy was trained in this extension. `experiments.py` evaluates seeds 3000–3099 and records preselected seed 3000 for every condition. Each episode is at most 150 actions (6 seconds); the physics timestep is 2 ms, control/detection period 40 ms. Raw JSON traces accompany videos. Videos append a 1-second frozen ending.

## Conditions

- `clean_rl`: original deterministic PPO and uncorrupted policy observations.
- `noisy_rl`: same PPO with independent zero-mean Gaussian observation noise. Relative object pose sigma 3 mm/axis; hand position 0.5 mm; hand velocity 5 mm/s; wrist force 0.05 N, torque 0.002 Nm; object velocity 10 mm/s. These are synthetic readout errors, not physical forces.
- `strong_noise_rl`: five times the policy-observation noise above. The separate detector still uses its base 0.05 N / 0.002 Nm noise.
- `forward_miss`: scripted approach, freezes the target when hand z drops below 95 mm; a real external +2 N x-force is applied for 0.12 s (0.24 Ns impulse), then removed. Closes on the stale target and lifts. This deliberately demonstrates an open-loop/stale-target failure, NOT evidence the PPO necessarily fails under this disturbance.
- `offset_collision`: scripted approach offset sideways by 55 mm, causing an open finger to hit the cube while descending. On wrist residual threshold crossing, rule-based controller opens and raises hand toward z=250 mm. No learned recovery. Matched no-retreat runs use same seeds and stop 1.5 s after first alarm.

## Six-axis detection versus grasp success

The fixed wrist-body site measures child-to-parent transmitted wrench in site-local axes. All three force and three torque channels are logged. Raw wrench includes gravity, inertia and contact; equal opposed squeeze forces can cancel at the wrist. Red arrow shows raw force, offset for visibility and scaled/clamped, not clamping force.

Detector runs a second identical MuJoCo model with contact disabled at the same qpos, qvel and actuator targets, and subtracts that no-contact predicted wrench from noisy actual readings. This is a privileged, matched-model residual, not a hardware-calibrated estimator. It is especially optimistic about model knowledge. At the policy sample rate, residual force norm >1.5 N OR torque norm >0.035 Nm triggers a latched alarm. Action changes on the next control step. It is not a safety-rated stop and cannot prevent the first impact. Sampling can miss substep peaks.

Crucially, the threshold also reacts to legitimate grasp contacts. In RL evaluations it is logged ONLY and does not override PPO actions. It is not a general dangerous-collision classifier. An implementation for a real robot would require phase-aware logic, calibration, latency tests, force/velocity limits and independently validated safety hardware.

Success remains BOTH finger normal forces >0.1 N and cube center z>0.10 m continuously for 0.6 seconds. An alarm is NOT evidence of a successful grasp. Contact forces are taken from the simulator for evaluation, not inferred from wrist force. Integrated finger-normal magnitude is a 25 Hz approximate contact-exposure metric, not a signed net impulse or damage score.

## Limitations

Narrow randomized initial pose and conveyor speed only; fixed geometry, mass, friction, single trained seed. Independent noise is not camera occlusion, latency, bias, colored noise or hardware reality. Counterfactual no-contact prediction has no uncertainty model. These experiments demonstrate failure and reaction, not certified safety, general robust grasping, or sim-to-real validity.

Official sensor semantics: https://mujoco.readthedocs.io/en/stable/XMLreference.html#sensor-force
