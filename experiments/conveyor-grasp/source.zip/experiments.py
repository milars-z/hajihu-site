import os
os.environ.setdefault('MUJOCO_GL','egl')
import json, subprocess
import mujoco
import numpy as np
import torch
from stable_baselines3 import PPO
from PIL import Image,ImageDraw,ImageFont
from conveyor import ConveyorEnv,ROOT

torch.set_num_threads(1)
POLICY=PPO.load(ROOT/'ppo_progress_policy.zip',device='cpu')
# Independent Gaussian per-axis readout errors, not physical perturbations.
def noisy(obs,rng,scale=1):
    o=obs.copy();o[:3]+=rng.normal(0,.003*scale,3);o[3:6]+=rng.normal(0,.0005*scale,3)
    o[6:9]+=rng.normal(0,.005*scale,3);o[11:14]+=rng.normal(0,.05*scale,3)/10
    o[14:17]+=rng.normal(0,.002*scale,3)/10;o[18:21]+=rng.normal(0,.01*scale,3)
    return o

def run(kind,seed=3000,video=False,guard=True):
    e=ConveyorEnv();o,_=e.reset(seed=seed);rng=np.random.default_rng(seed+90000)
    nominal=mujoco.MjModel.from_xml_path(str(ROOT/'scene.xml'));nominal.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_CONTACT);nd=mujoco.MjData(nominal)
    frozen=None;trigger=None;rows=[];pulse=0;peakF=0;peakT=0;collision=False;impulse=0;event=None;first_contact=None;contact_integral=0;peak_normal=0
    proc=None
    if video:
        proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','640x680','-r','25','-i','-','-an','-c:v','libx264','-pix_fmt','yuv420p',str(ROOT/(kind+'.mp4'))],stdin=subprocess.PIPE)
        font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
    for i in range(150):
        if kind in ['clean_rl','noisy_rl','strong_noise_rl']:
            a=POLICY.predict(o if kind=='clean_rl' else noisy(o,rng,5 if kind=='strong_noise_rl' else 1),deterministic=True)[0]
        else:
            p=e.data.xpos[e.obj].copy()
            if frozen is None and e.data.qpos[2]<.095:
                frozen=p.copy();event=i*.04
                if kind=='forward_miss':pulse=3
            target=(p if frozen is None else frozen).copy()
            target[0]+=.004
            if kind=='offset_collision':target[1]+=.055
            target[2]=.062
            if kind=='forward_miss' and frozen is not None and i*.04-event>.48:target[2]=.20
            if trigger is not None and guard and kind=='offset_collision':target=e.target.copy();target[2]=.25
            a=np.r_[np.clip((target-e.target)/[.012,.008,.008],-1,1),1 if frozen is not None and i*.04-event>.20 else -1]
            if trigger is not None and guard and kind=='offset_collision':a[3]=-1
        e.external_force=np.array([2.,0,0]) if pulse>0 else np.zeros(3)
        if pulse>0:pulse-=1;impulse+=.08
        o,r,t,tr,info=e.step(a)
        w=e.data.sensordata[:6].copy();measured=w+np.r_[rng.normal(0,.05,3),rng.normal(0,.002,3)]
        # Counterfactual no-contact model at same state/control predicts gravity and motion load.
        nd.qpos[:]=e.data.qpos;nd.qvel[:]=e.data.qvel;nd.ctrl[:]=e.data.ctrl
        mujoco.mj_forward(nominal,nd)
        residual=measured-nd.sensordata[:6]
        force=np.linalg.norm(residual[:3]);torque=np.linalg.norm(residual[3:]);peakF=max(peakF,force);peakT=max(peakT,torque)
        contact=bool(np.sum(info['finger_normal_N'])>.01);collision |= contact
        if contact and first_contact is None:first_contact=e.steps*.04
        contact_integral+=float(np.sum(info['finger_normal_N']))*.04;peak_normal=max(peak_normal,float(np.sum(info['finger_normal_N'])))
        alarm=bool(force>1.5 or torque>.035)
        if alarm and trigger is None:trigger=e.steps*.04
        rows.append(dict(t=e.steps*.04,object=e.data.xpos[e.obj].tolist(),hand=e.data.qpos[:3].tolist(),wrench=w.tolist(),measured=measured.tolist(),residual=residual.tolist(),force=float(force),torque=float(torque),finger=info['finger_normal_N'].tolist(),alarm=alarm,trigger=trigger,success=info['success']))
        if video:
            im=Image.new('RGB',(640,680),(15,20,29));im.paste(Image.fromarray(e.render()),(0,190));d=ImageDraw.Draw(im)
            state='RETRACT (rule, not learned)' if trigger is not None and guard and kind=='offset_collision' else 'RUN'
            lines=[f'{kind} | seed {seed} | {state}',f't={e.steps*.04:.2f}s; object z={info["height_m"]:.3f}m; success={info["success"]}',
                'Noisy wrist F [N]: '+', '.join(f'{v:+.3f}' for v in measured[:3]),'Noisy wrist T [Nm]: '+', '.join(f'{v:+.4f}' for v in measured[3:]),
                f'No-contact residual |F|={force:.3f}N |T|={torque:.4f}Nm',f'Alarm thresholds: 1.5N OR 0.035Nm | trigger={trigger}',
                f'Finger normal: {info["finger_normal_N"][0]:.3f}, {info["finger_normal_N"][1]:.3f}N',
                ('External +2N x pulse for 0.12s; frozen target' if kind=='forward_miss' else 'Red arrow = raw wrist force (gravity/inertia included)')]
            for j,line in enumerate(lines):d.text((8,5+j*22),line,font=font,fill='white')
            frame=np.asarray(im);proc.stdin.write(frame.tobytes())
        if kind in ['clean_rl','noisy_rl','strong_noise_rl'] and (t or tr):break
        if kind=='offset_collision' and trigger is not None and e.steps*.04-trigger>1.5:break
        if kind=='forward_miss' and frozen is not None and e.steps*.04-event>2.2:break
    if video:
        for _ in range(25):proc.stdin.write(frame.tobytes())
        proc.stdin.close();assert proc.wait()==0;im.save(ROOT/(kind+'.png'))
        (ROOT/(kind+'_trace.json')).write_text(json.dumps(rows,indent=2))
    result=dict(kind=kind,seed=seed,guard=guard,first_contact_s=first_contact,contact_normal_time_integral_Ns=contact_integral,peak_contact_normal_N=peak_normal,success=bool(info['success']),contact=collision,trigger_s=trigger,event_s=event,peak_residual_force_N=peakF,peak_residual_torque_Nm=peakT,external_impulse_Ns=impulse,final_object_z=info['height_m'],final_hand_z=float(e.data.qpos[2]),duration=e.steps*.04)
    e.close();return result
if __name__=='__main__':
    import sys
    if 'probe' in sys.argv:
        for k in ['clean_rl','noisy_rl','strong_noise_rl','forward_miss','offset_collision']:print(run(k),flush=True)
    else:
        allrows=[]
        for k in ['clean_rl','noisy_rl','strong_noise_rl','forward_miss','offset_collision']:
            rr=[run(k,s) for s in range(3000,3100)];allrows+=rr
            print(k,'success',sum(r['success'] for r in rr),'alarms',sum(r['trigger_s'] is not None for r in rr),'contacts',sum(r['contact'] for r in rr),flush=True)
            print('video',run(k,3000,True),flush=True)
        rr=[run('offset_collision',s,guard=False) for s in range(3000,3100)];allrows+=rr
        print('unguarded collision',len(rr),flush=True)
        (ROOT/'results.json').write_text(json.dumps(allrows,indent=2))
