import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).parent
rows=json.loads((p/'results.json').read_text());summary=[]
for kind,guard in [('clean_rl',True),('noisy_rl',True),('strong_noise_rl',True),('forward_miss',True),('offset_collision',True),('offset_collision',False)]:
 r=[x for x in rows if x['kind']==kind and x['guard']==guard]
 s={'kind':kind,'retreat_enabled':kind=='offset_collision' and guard,'n':len(r),'successes':sum(x['success'] for x in r),'alarms':sum(x['trigger_s'] is not None for x in r),'contacts':sum(x['contact'] for x in r),'mean_peak_sampled_normal_N':np.mean([x['peak_contact_normal_N'] for x in r]),'mean_contact_exposure_Ns':np.mean([x['contact_normal_time_integral_Ns'] for x in r]),'mean_final_hand_z':np.mean([x['final_hand_z'] for x in r])};summary.append(s)
(p/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
r=json.loads((p/'offset_collision_trace.json').read_text());t=[x['t'] for x in r];w=np.array([x['measured'] for x in r]);fig,axes=plt.subplots(3,1,figsize=(9,8),sharex=True)
for k in range(3):axes[0].plot(t,w[:,k],label='F'+'xyz'[k]);axes[1].plot(t,w[:,k+3],label='T'+'xyz'[k])
axes[2].plot(t,[x['hand'][2] for x in r],label='hand z');axes[2].plot(t,[x['object'][2] for x in r],label='cube z')
for a in axes:a.axvline(.56,color='red',ls='--',label='threshold / retreat trigger');a.legend(loc='upper right');a.grid(alpha=.3)
axes[0].set_ylabel('Force (N)');axes[1].set_ylabel('Torque (Nm)');axes[2].set_ylabel('Height (m)');axes[2].set_xlabel('Simulation time (s)');fig.suptitle('Actual MuJoCo offset collision, seed 3000 | 25 Hz noisy wrist readings');fig.tight_layout();fig.savefig(p/'wrist_collision.png',dpi=160)
