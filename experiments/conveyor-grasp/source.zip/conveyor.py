import os
os.environ.setdefault('MUJOCO_GL','egl')
import numpy as np
import mujoco
import gymnasium as gym
from gymnasium import spaces
from pathlib import Path
ROOT=Path(__file__).resolve().parent
class ConveyorEnv(gym.Env):
    metadata={'render_modes':['rgb_array'],'render_fps':25}
    def __init__(self,render_mode=None):
        self.model=mujoco.MjModel.from_xml_path(str(ROOT/'scene.xml'));self.data=mujoco.MjData(self.model)
        self.render_mode=render_mode;self.renderer=None
        self.action_space=spaces.Box(-1,1,(4,),np.float32)
        self.observation_space=spaces.Box(-np.inf,np.inf,(24,),np.float32)
        self.obj=mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_BODY,'object')
        self.cube=mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_GEOM,'cube')
        self.belt=mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_GEOM,'belt')
        self.fingers=[mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_GEOM,x) for x in ['finger_l','finger_r']]
        self.tcp=mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_SITE,'tcp')
    def contact_forces(self):
        forces=np.zeros(2);belt=False
        for k in range(self.data.ncon):
            c=self.data.contact[k];g={c.geom1,c.geom2}
            if self.cube in g:
                if self.belt in g:belt=True
                for i,f in enumerate(self.fingers):
                    if f in g:
                        wrench=np.zeros(6);mujoco.mj_contactForce(self.model,self.data,k,wrench);forces[i]+=max(0,wrench[0])
        return forces,belt
    def _obs(self):
        p=self.data.xpos[self.obj];tcp=self.data.site_xpos[self.tcp]
        return np.concatenate([p-tcp,self.data.qpos[:3],self.data.qvel[:3],self.data.qpos[3:5],self.data.sensordata[:6]/10,[self.speed],self.data.qvel[5:8],self.target-self.data.qpos[:3]]).astype(np.float32)
    def reset(self,seed=None,options=None):
        super().reset(seed=seed);mujoco.mj_resetData(self.model,self.data)
        self.speed=float(self.np_random.uniform(.07,.13));x=float(self.np_random.uniform(-.3,-.2));y=float(self.np_random.uniform(-.025,.025))
        self.data.qpos[:5]=[x-.03,y,.20,.035,.035];self.data.qpos[5:8]=[x,y,.021];self.data.qpos[8:12]=[1,0,0,0]
        self.target=self.data.qpos[:3].copy();self.data.ctrl[:3]=self.target;self.data.ctrl[3:]=.035
        mujoco.mj_forward(self.model,self.data)
        self.steps=0;self.hold=0;self.max_hold=0;self.success=False;self.ever_contact=False
        return self._obs(),{}
    def step(self,action):
        action=np.clip(action,-1,1)
        self.target+=action[:3]*np.array([.012,.008,.008]);self.target=np.clip(self.target,[-.55,-.1,.062],[.55,.1,.36])
        self.data.ctrl[:3]=self.target;self.data.ctrl[3:]=(.035*(1-action[3])/2)
        self.substep_wrenches=[]
        for _ in range(20):
            _,belt=self.contact_forces();self.data.xfrc_applied[self.obj,:]=0
            if belt:
                # Reduced belt contact model: bounded tangential drive ONLY while touching belt.
                self.data.xfrc_applied[self.obj,0]=np.clip(4*(self.speed-self.data.qvel[5]),-.9,.9)
            self.data.xfrc_applied[self.obj,:3]+=getattr(self,"external_force",np.zeros(3))
            mujoco.mj_step(self.model,self.data)
            self.substep_wrenches.append(self.data.sensordata[:6].copy())
        self.steps+=1
        f,belt=self.contact_forces();p=self.data.xpos[self.obj];tcp=self.data.site_xpos[self.tcp];d=np.linalg.norm(p-tcp)
        grasp=bool(min(f)>.1);self.ever_contact |= grasp
        lifted=p[2]>.10
        self.hold=self.hold+1 if grasp and lifted else 0;self.max_hold=max(self.hold,self.max_hold)
        self.success=self.hold>=15
        reward=1-np.tanh(8*d)+.5*grasp+4*max(0,min(p[2]-.02,.13))+.01*self.hold-.005*np.square(action[:3]).sum()
        if self.success:reward+=10
        term=bool(self.success or p[2]<-.02 or abs(p[0])>.6)
        trunc=self.steps>=180
        info={'success':self.success,'bilateral_contact':grasp,'finger_normal_N':f.copy(),'height_m':float(p[2]),'wrist_wrench':self.data.sensordata.copy(),'hold_steps':self.hold,'distance_m':float(d)}
        return self._obs(),float(reward),term,trunc,info
    def render(self):
        if self.renderer is None:self.renderer=mujoco.Renderer(self.model,height=480,width=640)
        self.renderer.update_scene(self.data,camera='overview')
        sc=self.renderer.scene
        # Orange arrow visualizes measured wrist force vector, not squeeze force.
        force=self.data.sensordata[:3].copy();wrist=self.data.site_xpos[mujoco.mj_name2id(self.model,mujoco.mjtObj.mjOBJ_SITE,'wrist_ft')]
        if np.linalg.norm(force)>1e-4:
            g=sc.geoms[sc.ngeom];mujoco.mjv_initGeom(g,mujoco.mjtGeom.mjGEOM_ARROW,np.zeros(3),np.zeros(3),np.eye(3).ravel(),np.array([1,.15,.05,1],np.float32));mujoco.mjv_connector(g,mujoco.mjtGeom.mjGEOM_ARROW,.006,wrist+np.array([.07,0,.03]),wrist+np.array([.07,0,.03])+np.clip(force*.07,-.20,.20));sc.ngeom+=1
        return self.renderer.render()
    def close(self):
        if self.renderer:self.renderer.close()
class Scripted:
    def __init__(self):self.phase=0;self.t=0
    def predict(self,env):
        p=env.data.xpos[env.obj];f,_=env.contact_forces();self.t+=1
        if self.phase==0 and np.linalg.norm(p[:2]-env.data.site_xpos[env.tcp,:2])<.012:self.phase=1
        if self.phase==1 and env.data.qpos[2]<.066:self.phase=2;self.t=0
        if self.phase==2 and min(f)>.15 and self.t>7:self.phase=3
        z=.062 if self.phase in [1,2] else .20
        lead=.004 if self.phase<3 else 0
        desired=np.array([p[0]+lead,p[1],z])
        act=np.clip((desired-env.target)/[.012,.008,.008],-1,1)
        return np.r_[act,1 if self.phase>=2 else -1]
if __name__=='__main__':
    env=ConveyorEnv();rows=[]
    for seed in range(10):
        env.reset(seed=seed);policy=Scripted();done=False
        while not done:
            _,r,t,tr,info=env.step(policy.predict(env));done=t or tr
        rows.append((seed,info['success'],env.steps,info['height_m'],info['finger_normal_N'].tolist(),policy.phase))
    print(rows)
